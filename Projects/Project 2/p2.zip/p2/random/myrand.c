int rand() {
	return 42;
}
